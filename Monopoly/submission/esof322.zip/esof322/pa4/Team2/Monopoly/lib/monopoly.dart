export 'src/components/app/app.dart';
